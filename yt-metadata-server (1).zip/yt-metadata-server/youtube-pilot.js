// youtube-pilot.js
// ---------------------------------------------------------------------------
// Channel-queue metadata pilot, ported from the Python "yt-tag-pilot" logic
// into the Node/Express "YouTube Pro" server (server.js).
//
// Flow:
//   1. Go to a target channel, take its latest N videos (default 3, shorts incl.)
//   2. For each video, take its TITLE and search YouTube for the most
//      "trending counterpart" (top result by view count for that title).
//   3. Read that counterpart's title, description, tags, categoryId.
//   4. Write them onto your video + set not-for-kids, and save.
//   5. Move on to the next channel in the queue.
//
// Shorts are INCLUDED — we never filter by duration.
// ---------------------------------------------------------------------------

const DEFAULT_PER_CHANNEL = 3;

// YouTube tag rules: <=500 chars total, dedup, strip junk, cap count.
function cleanTags(tags) {
  const seen = new Set();
  const out = [];
  let total = 0;
  for (let raw of tags || []) {
    if (!raw) continue;
    let t = String(raw).replace(/^#+/, '').trim();
    t = t.normalize('NFKD').replace(/[^\x00-\x7F]/g, '');
    t = t.replace(/[^a-zA-Z0-9 \-]/g, '').trim();
    if (!t) continue;
    const key = t.toLowerCase();
    if (seen.has(key)) continue;
    if (t.length > 60) t = t.slice(0, 60).trim();
    if (total + t.length + 1 > 480) break;
    seen.add(key);
    out.push(t);
    total += t.length + 1;
    if (out.length >= 30) break;
  }
  return out;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Find the "most trending counterpart" for a title: search by relevance, then
// rank candidates by view count, excluding the video itself and its channel.
async function findTrendingCounterpart(youtube, title, { excludeVideoId, excludeChannelId } = {}) {
  const q = String(title || '').slice(0, 100).trim();
  if (!q) return null;

  const search = await youtube.search.list({
    part: ['snippet'],
    q,
    type: ['video'],
    maxResults: 15,
    order: 'relevance',
  });

  const candidateIds = (search.data.items || [])
    .map((it) => it.id?.videoId)
    .filter((id) => id && id !== excludeVideoId);
  if (!candidateIds.length) return null;

  const details = await youtube.videos.list({
    part: ['snippet', 'statistics', 'status'],
    id: candidateIds,
  });

  const ranked = (details.data.items || [])
    .filter((v) => v.snippet?.channelId !== excludeChannelId)
    .map((v) => ({
      videoId: v.id,
      title: v.snippet?.title || '',
      description: v.snippet?.description || '',
      tags: v.snippet?.tags || [],
      categoryId: v.snippet?.categoryId || '22',
      channelTitle: v.snippet?.channelTitle || '',
      views: parseInt(v.statistics?.viewCount || '0', 10) || 0,
    }))
    .sort((a, b) => b.views - a.views);

  return ranked[0] || null;
}

// List a channel's latest N uploads (shorts included). Full snippet per video.
async function getLatestVideos(youtube, channelId, limit = DEFAULT_PER_CHANNEL) {
  const ch = await youtube.channels.list({ part: ['contentDetails'], id: [channelId] });
  const uploads = ch.data.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
  if (!uploads) return [];

  const pl = await youtube.playlistItems.list({
    part: ['snippet'],
    playlistId: uploads,
    maxResults: Math.min(limit, 50),
  });
  const ids = (pl.data.items || [])
    .map((it) => it.snippet?.resourceId?.videoId)
    .filter(Boolean);
  if (!ids.length) return [];

  const vids = await youtube.videos.list({ part: ['snippet'], id: ids });
  return (vids.data.items || []).map((v) => ({
    id: v.id,
    title: v.snippet?.title || '',
    description: v.snippet?.description || '',
    tags: v.snippet?.tags || [],
    categoryId: v.snippet?.categoryId || '22',
    channelId: v.snippet?.channelId,
  }));
}

// Write the counterpart's metadata onto our video + mark not-for-kids.
async function applyMetadata(youtube, targetVideoId, source) {
  const cur = await youtube.videos.list({ part: ['snippet', 'status'], id: [targetVideoId] });
  const item = cur.data.items?.[0];
  if (!item) return { ok: false, error: `Video ${targetVideoId} not found` };

  const snippet = item.snippet || {};
  const status = item.status || {};

  snippet.title = (source.title || snippet.title || 'Untitled').slice(0, 100);
  snippet.description = (source.description || '').slice(0, 5000);
  snippet.tags = cleanTags(source.tags);
  snippet.categoryId = source.categoryId || snippet.categoryId || '22';
  status.selfDeclaredMadeForKids = false; // "not for kids"

  try {
    await youtube.videos.update({
      part: ['snippet', 'status'],
      requestBody: { id: targetVideoId, snippet, status },
    });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err?.response?.data?.error?.message || err.message || String(err) };
  }
}

async function runChannel(youtube, channelId, { perChannel = DEFAULT_PER_CHANNEL, send = () => {}, supabase, userId } = {}) {
  const videos = await getLatestVideos(youtube, channelId, perChannel);
  send({ stage: 'channel_start', channelId, videoCount: videos.length });

  let success = 0;
  for (let i = 0; i < videos.length; i++) {
    const v = videos[i];
    send({ stage: 'video_start', channelId, index: i + 1, total: videos.length, title: v.title });

    let result = { ok: false, error: 'no counterpart found' };
    let source = null;
    try {
      source = await findTrendingCounterpart(youtube, v.title, {
        excludeVideoId: v.id,
        excludeChannelId: v.channelId,
      });
      if (source) result = await applyMetadata(youtube, v.id, source);
    } catch (err) {
      result = { ok: false, error: err?.response?.data?.error?.message || err.message || String(err) };
    }
    if (result.ok) success++;

    if (supabase && userId) {
      try {
        await supabase.from('pilot_logs').insert({
          user_id: userId,
          channel_id: channelId,
          video_id: v.id,
          old_title: v.title,
          new_title: source?.title || null,
          source_video_id: source?.videoId || null,
          source_channel: source?.channelTitle || null,
          new_tag_count: source ? cleanTags(source.tags).length : 0,
          status: result.ok ? 'success' : 'error',
          error: result.error || null,
          ran_at: new Date().toISOString(),
        });
      } catch (_) { /* best-effort */ }
    }

    send({
      stage: 'video_done',
      channelId,
      index: i + 1,
      total: videos.length,
      ok: result.ok,
      error: result.error || null,
      copiedFrom: source?.channelTitle || null,
    });

    await sleep(400);
  }

  send({ stage: 'channel_done', channelId, success, total: videos.length });
  return { channelId, success, total: videos.length };
}

async function runQueue(youtube, channelQueue, opts = {}) {
  const results = [];
  for (const channelId of channelQueue) {
    results.push(await runChannel(youtube, channelId, opts));
  }
  return results;
}

function registerPilotRoutes(app, deps) {
  const { google, supabase, getSession, ensureFreshSession, getAuthedClient } = deps;

  // POST /api/pilot/run  body: { channelQueue: ["UC..."], perChannel?: 3 }
  app.post('/api/pilot/run', async (req, res) => {
    const session = getSession(req);
    if (!session) return res.status(401).json({ error: 'Not authenticated' });

    const { channelQueue, perChannel } = req.body || {};
    if (!Array.isArray(channelQueue) || channelQueue.length === 0) {
      return res.status(400).json({ error: 'channelQueue (array of channel IDs) is required' });
    }

    try {
      await ensureFreshSession(req, res, session);
    } catch (err) {
      return res.status(401).json({ error: err.message });
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();
    const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    try {
      const youtube = google.youtube({ version: 'v3', auth: getAuthedClient(session.tokens) });
      send({ stage: 'queue_start', channels: channelQueue.length });
      const results = await runQueue(youtube, channelQueue, {
        // default 3, clamp 1..50
        perChannel: Math.min(Math.max(parseInt(perChannel, 10) || DEFAULT_PER_CHANNEL, 1), 50),
        send,
        supabase,
        userId: session.userId,
      });
      send({ stage: 'queue_done', results });
    } catch (err) {
      send({ stage: 'error', message: err?.response?.data?.error?.message || err.message || String(err) });
    }
    res.end();
  });
}

module.exports = {
  DEFAULT_PER_CHANNEL,
  cleanTags,
  findTrendingCounterpart,
  getLatestVideos,
  applyMetadata,
  runChannel,
  runQueue,
  registerPilotRoutes,
};
