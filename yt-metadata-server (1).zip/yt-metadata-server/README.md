# YouTube Pro — with Channel-Queue Metadata Pilot

Express app for managing YouTube metadata, now with the **pilot** feature ported
from `yt-tag-pilot`: for each channel in a queue it takes the **latest 3 videos
(shorts included)**, searches YouTube for each video's title, finds the most
"trending counterpart" (top result by view count), and copies that video's
title, description, tags, and category onto your video — and marks it not-for-kids.

## Run locally

```bash
npm install
cp .env.example .env      # then fill in your Google OAuth values
node server.js            # → http://localhost:3000
```

Open http://localhost:3000, sign in with Google, then trigger the pilot.

### Google OAuth setup
In Google Cloud Console → APIs & Services:
1. Enable **YouTube Data API v3**.
2. Create an **OAuth client (Web application)**.
3. Add Authorized redirect URI: `http://localhost:3000/auth/callback`.
4. Put the client ID/secret into `.env`.

The write scope (`youtube.force-ssl`) is already requested at login, so no extra
configuration is needed for the pilot to edit videos.

### Supabase is optional
If `SUPABASE_URL` / `SUPABASE_ANON_KEY` are unset, the app runs with an
in-memory no-op stub — it boots and the pilot works; only history/logs are
disabled. To persist the pilot audit log, set those vars and create:

```sql
create table if not exists pilot_logs (
  id bigint generated always as identity primary key,
  user_id uuid, channel_id text, video_id text,
  old_title text, new_title text,
  source_video_id text, source_channel text,
  new_tag_count int, status text, error text,
  ran_at timestamptz default now()
);
```

## Using the pilot

```js
const res = await fetch('/api/pilot/run', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    channelQueue: ['UCxxxxxxxx', 'UCyyyyyyyy'], // channels, in order
    perChannel: 3,                              // default 3, max 50
  }),
});
// res.body is a Server-Sent Events stream.
```

Progress events: `queue_start`, `channel_start`, `video_start`,
`video_done` (`ok`/`error`/`copiedFrom`), `channel_done`, `queue_done`, `error`.

## Heads-up before running on real channels
- **It overwrites your real titles/descriptions/tags** with another creator's
  metadata. The audit log keeps the old title for rollback.
- **Quota:** each video does one `search.list` (~100 units). 3 videos × a few
  channels stays well under the default 10,000/day quota.
- **Policy:** copying a popular video's title/description verbatim can read as
  misleading and may collide with the source's branding/IP. A safer variant is
  to use the counterpart only for tags/keywords.

See `INTEGRATION.md` for how `youtube-pilot.js` plugs into `server.js`.
