# Wiring `youtube-pilot.js` into the existing server

This adds the yt-tag-pilot channel-queue logic to your Node/Express
"YouTube Pro" app (`server.js`) without rewriting it.

## 1. Drop the file in

Put `youtube-pilot.js` next to `server.js`.

## 2. Add two lines to `server.js`

Near the top, after the other `require`s:

```js
const { registerPilotRoutes } = require('./youtube-pilot');
```

After all your route definitions but **before** `app.listen(...)`:

```js
registerPilotRoutes(app, {
  google,               // already imported in server.js
  supabase,             // already created in server.js
  getSession,           // existing helper
  ensureFreshSession,   // existing helper
  getAuthedClient,      // existing helper
});
```

That's it — the module reuses your existing OAuth/session/token-refresh code,
so it authenticates exactly like `/api/search` and `/api/upload`.

## 3. (Optional) Supabase table for the audit log

If you want the run history persisted (the module logs best-effort and
silently skips if the table is absent):

```sql
create table if not exists pilot_logs (
  id            bigint generated always as identity primary key,
  user_id       uuid,
  channel_id    text,
  video_id      text,
  old_title     text,
  new_title     text,
  source_video_id text,
  source_channel  text,
  new_tag_count int,
  status        text,
  error         text,
  ran_at        timestamptz default now()
);
```

## 4. Run it

The queue runs over Server-Sent Events, same as your upload endpoint:

```js
const res = await fetch('/api/pilot/run', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    channelQueue: ['UCxxxxxxxx', 'UCyyyyyyyy'], // channels, in order
    perChannel: 10,
  }),
});
// then read res.body as an SSE stream and surface the `stage` events.
```

Progress events you'll receive: `queue_start`, `channel_start`,
`video_start`, `video_done` (with `ok`/`error`/`copiedFrom`),
`channel_done`, `queue_done`, and `error`.

## How the flow maps to your spec

1. `getLatestVideos(channelId, 10)` — latest 10 uploads of the target channel.
2. `findTrendingCounterpart(title)` — YouTube-searches the video's title,
   then ranks the results by view count and picks the top one (excluding the
   video itself and its own channel).
3. It reads that counterpart's **title, description, tags, categoryId**.
4. `applyMetadata(...)` writes them onto your video via `videos.update` and
   sets `status.selfDeclaredMadeForKids = false` (not for kids), then saves.
   Repeats for the remaining 9 videos.
5. `runQueue(...)` moves to the next channel in the queue.

## Things worth knowing before you run it on a real channel

- **It overwrites your real titles/descriptions/tags** with another creator's
  metadata. That's exactly what was asked, but it's destructive — the audit log
  records the old title so you can roll back, and you may want a `dryRun` pass
  first (easy to add: skip the `applyMetadata` call and just emit the proposed
  source).
- **Quota:** every video does one `search.list` (100 units) + a couple of
  cheap reads/writes. 10 videos × 2 channels ≈ ~2,000+ units against a default
  10,000/day quota — a few channels will exhaust it.
- **Scope:** writing metadata needs the `youtube.force-ssl` scope, which your
  app already requests, so no OAuth change is needed.
- **Policy:** copying a popular video's title/description verbatim can read as
  misleading metadata and may collide with the source's branding/IP. Consider
  using the counterpart only as a *source of tags/keywords* (closer to the
  original tag-pilot, which generated fresh descriptions) rather than a 1:1 copy.
